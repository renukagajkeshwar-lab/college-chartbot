from flask import Flask, render_template, jsonify, request
import json
import os
import re

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")


def load_json(filename, default=None):
    path = os.path.join(DATA_DIR, filename)

    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        print(f"Could not load {filename}: {e}")
        return default if default is not None else {}


college_info = load_json("college_info.json", {})
departments_data = load_json("departments.json", [])
official_data = load_json("official_data.json", {})


def get_departments():
    if isinstance(departments_data, dict):
        return departments_data.get("departments", [])
    return departments_data


def normalize(text):
    text = text.lower()
    text = text.replace("cse aiml", "aiml")
    text = text.replace("cse (aiml)", "aiml")
    text = text.replace("cse(a iml)", "aiml")

    replacements = {
        "kon aahe": "who",
        "kon": "who",
        "cha": "of",
        "chi": "of",
        "madhe": "in",
        "kontya": "which",
        "ahe": "is",
        "aahet": "are",
        "sang": "tell",
        "pahije": "want",
        "college madhe": "college",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    return re.sub(r"\s+", " ", text).strip()


def find_department(question):
    q = normalize(question)

    departments = get_departments()

    aliases = {
        "aiml": "Computer Science & Engineering (AIML)",
        "artificial intelligence machine learning":
            "Computer Science & Engineering (AIML)",
        "cse": "Computer Science & Engineering",
        "computer science": "Computer Science & Engineering",
        "aids": "Artificial Intelligence & Data Science",
        "ai ds": "Artificial Intelligence & Data Science",
        "ai data science": "Artificial Intelligence & Data Science",
        "extc": "Electronics & Telecommunication Engineering",
        "electrical": "Electrical Engineering",
        "ee": "Electrical Engineering",
        "mechanical": "Mechanical Engineering",
        "me": "Mechanical Engineering",
        "civil": "Civil Engineering",
        "mba": "MBA",
        "mca": "MCA",
    }

    for alias, department_name in aliases.items():
        if alias in q:
            return next(
                (
                    d for d in departments
                    if d.get("name", "").lower() == department_name.lower()
                ),
                None
            )

    for department in departments:
        name = department.get("name", "").lower()

        if name and name in q:
            return department

    return None


def search_official_pages(question):
    """
    Searches the collected official website data.
    """
    if not isinstance(official_data, dict):
        return []

    pages = official_data.get("pages", [])

    if not isinstance(pages, list):
        return []

    words = [
        w for w in normalize(question).split()
        if len(w) > 2
    ]

    results = []

    for page in pages:
        title = str(page.get("title", "")).lower()
        content = " ".join(page.get("content", [])).lower()

        score = 0

        for word in words:
            if word in title:
                score += 3
            if word in content:
                score += 1

        if score > 0:
            results.append((score, page))

    results.sort(key=lambda x: x[0], reverse=True)

    return [page for score, page in results[:5]]


def answer_question(question):
    q = normalize(question)

    # -------------------------------
    # GREETING
    # -------------------------------
    if any(x in q for x in [
        "hello", "hi", "hey", "namaste", "good morning",
        "good afternoon", "good evening"
    ]):
        return (
            "Hello! 👋 I am the P.R. Pote AI College Assistant. "
            "I can help you with departments, HODs, faculty, "
            "courses, facilities, syllabus, timetable and examinations."
        )

    # -------------------------------
    # COLLEGE
    # -------------------------------
    if any(x in q for x in [
        "about college",
        "college information",
        "college details",
        "college"
    ]) and not any(x in q for x in ["hod", "faculty"]):

        name = college_info.get(
            "college_name",
            "P. R. Pote Patil College of Engineering & Management"
        )

        city = college_info.get("city", "Amravati")
        state = college_info.get("state", "Maharashtra")
        established = college_info.get("established", "Not available")
        status = college_info.get("status", "Not available")

        return (
            f"🏫 {name}\n\n"
            f"📍 Location: {city}, {state}\n"
            f"📅 Established: {established}\n"
            f"🏛️ Status: {status}"
        )

    # -------------------------------
    # HOD
    # -------------------------------
    if any(x in q for x in [
        "hod", "head", "department head", "head of"
    ]):
        department = find_department(question)

        if department:
            hod = department.get("hod")

            if hod:
                return (
                    f"👔 HOD Information\n\n"
                    f"Department: {department.get('name')}\n"
                    f"HOD: {hod}"
                )

        return (
            "I couldn't identify the department or find its HOD "
            "in the college database."
        )

    # -------------------------------
    # DEPARTMENTS
    # -------------------------------
    if any(x in q for x in [
        "departments",
        "department",
        "branches",
        "branches available",
        "courses available"
    ]):
        departments = get_departments()

        if departments:
            lines = ["🏫 Departments at PRPCEM:\n"]

            for i, department in enumerate(departments, 1):
                lines.append(
                    f"{i}. {department.get('name', 'Unknown')}"
                )

            return "\n".join(lines)

    # -------------------------------
    # FACILITIES
    # -------------------------------
    if any(x in q for x in [
        "facility",
        "facilities",
        "infrastructure",
        "campus"
    ]):
        facilities = college_info.get("facilities", [])

        if facilities:
            return (
                "🏢 College Facilities:\n\n" +
                "\n".join(f"• {item}" for item in facilities)
            )

    # -------------------------------
    # COURSE / DEGREE
    # -------------------------------
    if any(x in q for x in [
        "degree",
        "course",
        "programme",
        "program",
        "intake"
    ]):
        department = find_department(question)

        if department:
            answer = (
                f"🎓 {department.get('name')}\n\n"
                f"Degree: {department.get('degree', 'Not available')}"
            )

            if department.get("duration"):
                answer += f"\nDuration: {department.get('duration')}"

            if department.get("intake"):
                answer += f"\nIntake: {department.get('intake')}"

            return answer

    # -------------------------------
    # SYLLABUS
    # -------------------------------
    if "syllabus" in q or "scheme" in q:
        return (
            "📘 Official Syllabus\n\n"
            "The official Academic Portal provides syllabus and scheme "
            "documents by admission year, academic session, degree, "
            "branch and semester.\n\n"
            "Use the official Academic Portal button below to select "
            "your branch and semester."
        )

    # -------------------------------
    # TIMETABLE
    # -------------------------------
    if "timetable" in q or "time table" in q:
        return (
            "📅 Official Examination Timetable\n\n"
            "The official Examination Cell provides timetables using "
            "admission year, degree, branch, semester and exam type filters.\n\n"
            "Use the Official Timetable button below."
        )

    # -------------------------------
    # EXAM
    # -------------------------------
    if any(x in q for x in [
        "exam",
        "examination",
        "end semester",
        "ese"
    ]):
        return (
            "📝 Examination Information\n\n"
            "The official PRPCEM Examination Cell publishes "
            "examination notices, timetables, forms and procedures.\n\n"
            "Use the Official Exam Cell button to view the latest information."
        )

    # -------------------------------
    # LIBRARY
    # -------------------------------
    if "library" in q:
        facilities = college_info.get("facilities", [])

        if "Library" in facilities:
            return (
                "📖 Library is listed among the college facilities."
            )

    # -------------------------------
    # FACULTY
    # -------------------------------
    if any(x in q for x in [
        "faculty",
        "teachers",
        "teacher",
        "professors"
    ]):
        department = find_department(question)

        if department:
            return (
                f"👨‍🏫 Faculty information for "
                f"{department.get('name')} is available through "
                f"the official department page.\n\n"
                f"Use the Official College Website button below."
            )

        return (
            "👨‍🏫 Please mention the department, for example:\n"
            "\"AIML faculty\" or \"CSE faculty\"."
        )

    # -------------------------------
    # OFFICIAL DATA SEARCH
    # -------------------------------
    results = search_official_pages(question)

    if results:
        page = results[0]

        content = page.get("content", [])

        useful = content[:8]

        return (
            "🔎 I found this information in the collected official "
            "college data:\n\n" +
            "\n".join(f"• {x}" for x in useful) +
            f"\n\nSource: {page.get('url', '')}"
        )

    # -------------------------------
    # NO FAKE ANSWERS
    # -------------------------------
    return (
        "🤖 I couldn't find that information in the official "
        "college database.\n\n"
        "Try asking about:\n"
        "• Departments\n"
        "• HOD\n"
        "• Faculty\n"
        "• Courses\n"
        "• Facilities\n"
        "• Syllabus\n"
        "• Timetable\n"
        "• Exams"
    )


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/college")
def get_college_info():
    return jsonify(college_info)


@app.route("/api/departments")
def get_departments_api():
    return jsonify(get_departments())


@app.route("/api/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}

    question = str(data.get("question", "")).strip()

    if not question:
        return jsonify({
            "answer": "Please type or speak your question."
        })

    answer = answer_question(question)

    return jsonify({
        "answer": answer
    })


@app.route("/api/official")
def get_official():
    return jsonify(official_data)


if __name__ == "__main__":
    app.run(debug=True)